package com.gomes.senai.model.enums;

public enum StatusLancamento {
	PENDENTE,
	CANCELADO,
	EFETIVADO
}
