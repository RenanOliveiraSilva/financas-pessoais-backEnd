package com.gomes.senai.model.enums;

public enum TipoLancamento {
	RECEITA,
	DESPESA
}
