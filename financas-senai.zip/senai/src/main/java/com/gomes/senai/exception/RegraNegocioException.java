package com.gomes.senai.exception;

public class RegraNegocioException extends RuntimeException {
	public RegraNegocioException(String msg) {
		super(msg);
	}
}
