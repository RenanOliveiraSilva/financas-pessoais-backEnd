package com.gomes.senai.exception;

public class ErroAutenticacao extends RuntimeException{
	public ErroAutenticacao(String msg){
		super(msg);
	}
}
